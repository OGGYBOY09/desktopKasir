/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kasir;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ISSI
 */
public class KoneksiDatabase {
  public static Connection getConnection() {
        Connection connection = null;
        try {
            // Ganti URL, user, dan password sesuai database kamu
            String url = "jdbc:postgresql://localhost:5432/db_restorant";
            String user = "postgres";
            String password = "12345";

            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Koneksi berhasil!");
        } catch (SQLException e) {
            System.out.println("Koneksi gagal: " + e.getMessage());
        }
        return connection;
    }  
}
